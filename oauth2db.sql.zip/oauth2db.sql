-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Dim 10 Mars 2019 à 08:52
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `oauth2db`
--

-- --------------------------------------------------------

--
-- Structure de la table `api_access_scope`
--

CREATE TABLE IF NOT EXISTS `api_access_scope` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  `description` varchar(254) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_E350F02D5E237E06` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='liste tout les scopes disponible' AUTO_INCREMENT=76 ;

--
-- Contenu de la table `api_access_scope`
--

INSERT INTO `api_access_scope` (`id`, `name`, `is_default`, `description`) VALUES
(66, 'public_profile', 1, 'les informations public tel, le nom d''utilisateur...'),
(67, 'email', 1, 'votre adresse email'),
(68, 'phone', 1, 'votre numero de telephone'),
(69, 'balance', 0, 'votre solde bancaire'),
(70, 'transaction', 0, 'vos transactions'),
(71, 'readsms', 0, 'consulter et lire vos sms'),
(72, 'writesms', 0, 'envoyer des sms'),
(73, 'coa_public_profile', 1, 'les informations public comme: le nom, la fonction et le departement et le numéro de téléphone fixe du bureau de l''employé'),
(75, 'coa_salary', 1, 'le salaire de l''utilisateur');

-- --------------------------------------------------------

--
-- Structure de la table `api_user_access_code`
--

CREATE TABLE IF NOT EXISTS `api_user_access_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `code` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `redirect_uri` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expires` datetime NOT NULL,
  `scope` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `token` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_6A493A5F77153098` (`code`),
  KEY `IDX_6A493A5F3E030ACD` (`application_id`),
  KEY `IDX_6A493A5FA76ED395` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='les authorization_code des utilisateurs' AUTO_INCREMENT=70 ;

--
-- Contenu de la table `api_user_access_code`
--

INSERT INTO `api_user_access_code` (`id`, `application_id`, `user_id`, `code`, `redirect_uri`, `expires`, `scope`, `token`, `date`) VALUES
(55, 11, 439, 'OTFiYTUwYWQ1Y2I4NzE3YzM5ZTllYjI2', 'http://localhost/soutraly/login?m=3', '2018-05-24 14:42:28', 'public_profile email', 'NGFlY2JkNWM0YTAyMjg4ZjNhOWI2NmFmOGFiMDE1NzJjNTAxZTcyYWFhMWNiNzlm', '2018-05-24 14:39:28'),
(56, 11, 439, 'YWU2MTNmOGM3N2IxYzEzNWUyMTA3ZmRl', 'http://localhost/soutraly/login?m=3', '2018-05-24 14:54:52', 'public_profile email', 'NjM2YWNiNzc1YTBlY2YyNjc1ZGVmMzU5ZDczOTllMzYzODQzMzMyODE4OWYyMTE1', '2018-05-24 14:51:52'),
(57, 11, 439, 'OTM5YjAyMGNmNDY5MTAwMjZhNTA0YzBh', 'http://localhost/soutraly/login?m=3', '2018-05-24 14:55:05', 'public_profile email', 'OGI5YzU4OTczYjM4YzJiYmM0ZDlhNTFmOGU4Zjc5ZThlNGFmYmJhYjQ1MTIwMDVl', '2018-05-24 14:52:05'),
(58, 11, 439, 'NjU1Zjg0M2M1YTEzNTg5OWIzOTIwZDE5', 'http://localhost/soutraly/login?m=3', '2018-05-24 14:55:39', 'public_profile email', 'MWE2MTE1Yjc0NjAyMWVhYzk2ZGRiZTE4NDZlM2NlNTc1YzhlNGI4ZDc2MzU2OTA3', '2018-05-24 14:52:39'),
(59, 11, 439, 'MjFiYjIyNGRhYjhjYzZmM2EyMjM4MmQ3', 'http://localhost/soutraly/login?m=3', '2018-05-24 16:11:20', 'public_profile email', 'ZTI5N2E1N2U3Y2MwOGM5ZWMyMzk4NDEzMDU2YjI1N2NmZmRmMzAzYmQ4ZDdlM2Nk', '2018-05-24 16:08:20'),
(60, 11, 439, 'MDI5NjQxZjA5ZTE1NDVhM2JlMzMxYTk4', 'https://www.getpostman.com/oauth2/callback', '2018-05-25 15:52:42', 'public_profile email', NULL, '2018-05-25 15:49:42'),
(61, 11, 439, 'ZmNhZTgzYjZlMmY1NTU1ZDUyYWVlMTI3', 'https://www.getpostman.com/oauth2/callback', '2018-05-25 15:53:44', 'public_profile email', NULL, '2018-05-25 15:50:44'),
(62, 11, 439, 'MDQ0NjIwN2NjMWMyMjFlZGE5OGJiMDJm', 'https://www.getpostman.com/oauth2/callback', '2018-05-25 15:54:49', 'public_profile email', NULL, '2018-05-25 15:51:49'),
(63, 11, 439, 'NDcxZmU0YzU1YmI4ZTlmNWNiOTI2MWY2', 'https://www.getpostman.com/oauth2/callback', '2018-05-25 15:56:37', 'public_profile email', NULL, '2018-05-25 15:53:37'),
(64, 11, 439, 'NWU5MWNiMzg5NjI4YjcxZGQzNTRlY2U1', 'https://www.getpostman.com/oauth2/callback', '2018-05-25 15:57:00', 'public_profile email', NULL, '2018-05-25 15:54:00'),
(65, 11, 439, 'MTM0MzE3OWY0ZGViZmRiYTU2MmI5YTBl', 'http://localhost/soutraly/login?m=3', '2018-05-25 17:26:17', 'public_profile email', NULL, '2018-05-25 17:23:17'),
(66, 11, 439, 'NDg2NWUwZTY5MmM3NmM5ZmJkZjk1NTRm', 'http://localhost/soutraly/login?m=3', '2018-05-25 17:26:49', 'public_profile email', NULL, '2018-05-25 17:23:49'),
(67, 11, 439, 'ZTE0NWMxNGNmZmExNDdlNDFjYjcxZjdk', 'http://localhost/soutraly/login?m=3', '2018-05-25 20:40:41', 'public_profile email', 'MzZjN2VmNmVlMDE3YjY0M2FmNjg2OWY3ZTM3MTkxNDhiZjY5ZjY2MDMxZDI4NGRh', '2018-05-25 20:37:41'),
(68, 20, 439, 'MDg4MzQ0ZDYyNzAwMWJjZDM0M2UzNDhi', 'http://localhost/soutraly/login?m=3', '2018-05-29 09:20:33', 'public_profile email', NULL, '2018-05-29 09:17:33'),
(69, 11, 439, 'NzEzOWVjZGZlZTBlNGMxZDE4NTBmYjZi', 'http://localhost/soutraly/login?m=3', '2018-05-29 09:21:23', 'public_profile email', 'MTU1YTZlZTgyMDhkYzM3ODU4YzQ2ZmYwOTM1ZTk1YTYyZjFmOTk0MzVhYjJlOWIw', '2018-05-29 09:18:23');

-- --------------------------------------------------------

--
-- Structure de la table `api_user_access_token`
--

CREATE TABLE IF NOT EXISTS `api_user_access_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `refresh_token` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_token_revoke` tinyint(1) NOT NULL,
  `is_refresh_token_revoke` tinyint(1) NOT NULL,
  `date` datetime NOT NULL,
  `expires` datetime NOT NULL,
  `grant_type` enum('authorization_code','implicit','password','client_credentials','refresh_token') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_5A2AAA225F37A13B` (`token`),
  KEY `IDX_5A2AAA223E030ACD` (`application_id`),
  KEY `IDX_5A2AAA22A76ED395` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='les access_token des utilisateurs' AUTO_INCREMENT=91 ;

--
-- Contenu de la table `api_user_access_token`
--

INSERT INTO `api_user_access_token` (`id`, `application_id`, `user_id`, `token`, `refresh_token`, `is_token_revoke`, `is_refresh_token_revoke`, `date`, `expires`, `grant_type`) VALUES
(69, 11, 439, 'NGFlY2JkNWM0YTAyMjg4ZjNhOWI2NmFmOGFiMDE1NzJjNTAxZTcyYWFhMWNiNzlm', 'MGUxYmI3N2VmNGU3YjM2NjA0ZTE2ODE3', 1, 1, '2018-05-24 14:39:30', '2018-08-22 14:39:30', 'authorization_code'),
(70, 11, 439, 'NjM2YWNiNzc1YTBlY2YyNjc1ZGVmMzU5ZDczOTllMzYzODQzMzMyODE4OWYyMTE1', 'NmE1OTllMDlmODkzMmU1NDk5OTBjZGNk', 1, 1, '2018-05-24 14:51:53', '2018-08-22 14:51:53', 'authorization_code'),
(71, 11, 439, 'OGI5YzU4OTczYjM4YzJiYmM0ZDlhNTFmOGU4Zjc5ZThlNGFmYmJhYjQ1MTIwMDVl', 'NmQ0MTczYjI4OWRlY2MzNGYwNDkxMmM3', 1, 1, '2018-05-24 14:52:07', '2018-08-22 14:52:07', 'authorization_code'),
(72, 11, 439, 'MWE2MTE1Yjc0NjAyMWVhYzk2ZGRiZTE4NDZlM2NlNTc1YzhlNGI4ZDc2MzU2OTA3', 'OWI4NDIzNzJlM2YyMWEyNTk2M2Y4OWM5', 1, 1, '2018-05-24 14:52:41', '2018-08-22 14:52:41', 'authorization_code'),
(73, 11, 439, 'ZTI5N2E1N2U3Y2MwOGM5ZWMyMzk4NDEzMDU2YjI1N2NmZmRmMzAzYmQ4ZDdlM2Nk', 'NTc4NmUyNWViMTA2NTNiMTEwN2IyYzBm', 0, 0, '2018-05-24 16:08:22', '2018-08-22 16:08:22', 'authorization_code'),
(74, 11, 439, 'ODYzODhkNTA2YTgzOTVlNmRlYTViZTQ3OGU5YTlkYzVmOTc3N2U2Mjg5NTY1YTlm', 'YTQ5NGMwNjYwYzM4YjJlZjEwMmZkMjY5', 0, 0, '2018-05-24 16:12:50', '2018-08-22 16:12:50', 'refresh_token'),
(75, 11, 439, 'ODcyMjU4YTViYzY5Y2ZiNzQ4NjM1ZGQ2Yzk0ODM0NTljNmJmZTU5NjllMDhkODk1', 'YjI2Y2Y5NGNkY2Q3OGYxMTMxYjg4YmUw', 0, 0, '2018-05-24 16:13:31', '2018-08-22 16:13:31', 'refresh_token'),
(76, 11, 439, 'MTU1ZmRiMTA2YTM1OWI0Mjc0ODdmYmRiMTRmOGU3YTdjMzE2MzI0NTIxMjc1MzAw', 'ZWZmNWFiNWUyZDY3NGU5YjM1OWIwMDg1', 0, 0, '2018-05-24 16:19:12', '2018-08-22 16:19:12', 'implicit'),
(77, 11, 439, 'YmJhMjUyNWE3NzgzNjBlYWVmMmY3ZGQ2NzRjY2QyY2JjYzEwZjA4Zjc4N2E4ZmIy', 'NDUyNzY4MTVkZTQ2ZDMyM2Y5MDZkNWQ4', 1, 1, '2018-05-25 15:06:24', '2018-08-23 15:06:24', 'refresh_token'),
(78, 11, 439, 'YjU1NzNkOWRhNDNiMWQwYjk0YTljNjVlZjk2MWMwMzI3NWE5NjQyZjAwY2NlMTBi', 'MTE2ZjkzOTFiMzFhMjlkYzRiMTRjODg5', 0, 0, '2018-05-25 16:28:31', '2018-08-23 16:28:31', 'refresh_token'),
(79, 11, 439, 'ZTk5MzcwY2Q4YzJiYjNmYjgxNjUyNjllYmUxYmMwYmMyMThkYmE3YTI1OWNkNTI0', 'ZDQ5MzMzMDFiZTEwODg1Y2U2ZjBlYzgx', 0, 0, '2018-05-25 17:19:57', '2018-08-23 17:19:57', 'implicit'),
(80, 11, 439, 'MzZjN2VmNmVlMDE3YjY0M2FmNjg2OWY3ZTM3MTkxNDhiZjY5ZjY2MDMxZDI4NGRh', 'YjFmZDc2MmZjNGJiZDFjNWE5MmFhMWZk', 1, 1, '2018-05-25 20:37:59', '2018-08-23 20:37:59', 'authorization_code'),
(81, 11, 450, 'MDhiYmRlYjk1MGFlNGU0YjU1YjU1NzliZDcyYzhmMDRkMjQ2OTYyNzgyODZmNWQ5', 'ZjQ5YzA1NWYzZGYwNWE1ODY2NzkxZDA5', 0, 0, '2018-05-25 20:47:57', '2018-08-23 20:47:57', 'client_credentials'),
(82, 11, 450, 'NjRiNjNjZjFiNDExZmZmNGU3ZWZhMTI3NGRmMzAzZWJkZjkyYmJiMzA1Y2ExYTZj', 'Y2MyNmU3NjI4OWFmOTNlMjljZGZmMTE1', 0, 0, '2018-05-25 20:48:38', '2018-08-23 20:48:38', 'client_credentials'),
(83, 11, 450, 'OGQxMGMwMWE5YmVkY2ZhNGFkY2M4MTZiYWM4ZjIwZWNiMjRkNzgyN2Q1YjIwODVh', 'MzlkOTA0NDk3NjU4MGJiM2Q1MmM0NThl', 0, 0, '2018-05-25 20:50:03', '2018-08-23 20:50:03', 'client_credentials'),
(84, 11, 450, 'YTdlMjEyNTA1MzVjZTlhNzEwMjkzYjdlMWI1YzJiNzEwYTJmNzY0MjNiZDYzMzhk', 'MThkYWFmZWM0NjE4ODlhY2JlNWRlYjhj', 0, 0, '2018-05-25 20:50:31', '2018-08-23 20:50:31', 'client_credentials'),
(85, 11, 439, 'MjE4NGJhOTU3NGU4OTA0NTA1ZjkxNjMzNDc3M2U1MjBhNmE2MDFlNWEwMDRjMjQ1', 'ZjdkZWZkNTdmNWIyYzQ5ZjIxNjdkNmVh', 0, 0, '2018-05-25 20:57:18', '2018-08-23 20:57:18', 'password'),
(86, 11, 439, 'ZjFkNzQwMGQ0YWQ2YzRhMWU2YTgyMWU2YmFjZmVlOWU5NDU0MzYzMTBhM2VhNzIw', 'N2IxNWFhMjJlYTNmYzFiOTRiMWJkZTQw', 0, 1, '2018-05-25 21:06:49', '2018-08-23 21:06:49', 'password'),
(87, 11, 439, 'YjBjMTQwMzViYTk5NDUwNDZiNmRiZTU3OTE0YTA3OGNiMjU2YTUyOTVmZDZiZDI3', 'NzE2NjU2MDE2OTU0Y2JkMDFiNGE0MDg1', 0, 0, '2018-05-26 11:17:50', '2018-08-24 11:17:50', 'refresh_token'),
(88, 20, 461, 'YTBjOTk1MTI3YmEwMzdlNjE2OTlhMWUzMDkyODRiMGJhZjgzNzc1ZWJmMmQ5ODcx', 'MmFlZTBmOGZjNzEwNDczMmIxMWZhZDc1', 1, 1, '2018-05-28 16:09:47', '2018-08-26 16:09:47', 'client_credentials'),
(89, 20, 461, 'MWQ0ZTk0ZDNkMzc3NzZmZDY3MzE0MWM2ZmIxMTI2YTE1MWYwZjMxZDhiMTNmMDQz', 'N2QzNzY4YjdhMzEzNDg5Y2IxZTBmMTFl', 0, 0, '2018-05-28 16:14:36', '2018-08-26 16:14:36', 'client_credentials'),
(90, 11, 439, 'MTU1YTZlZTgyMDhkYzM3ODU4YzQ2ZmYwOTM1ZTk1YTYyZjFmOTk0MzVhYjJlOWIw', 'NDFiNDg5MTM3MWI2ZTJkMjNjNDExODI3', 0, 0, '2018-05-29 09:18:25', '2018-08-27 09:18:25', 'authorization_code');

-- --------------------------------------------------------

--
-- Structure de la table `api_user_access_token_scope`
--

CREATE TABLE IF NOT EXISTS `api_user_access_token_scope` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token_id` int(11) NOT NULL,
  `scope_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_54C07E7941DEE7B9` (`token_id`),
  KEY `IDX_54C07E79682B5931` (`scope_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='les scopes demandé pour un access_token utilisateur' AUTO_INCREMENT=106 ;

--
-- Contenu de la table `api_user_access_token_scope`
--

INSERT INTO `api_user_access_token_scope` (`id`, `token_id`, `scope_id`, `date`) VALUES
(69, 73, 10, '2018-05-24 16:08:22'),
(70, 73, 11, '2018-05-24 16:08:22'),
(71, 74, 10, '2018-05-24 16:12:50'),
(72, 74, 11, '2018-05-24 16:12:50'),
(73, 75, 10, '2018-05-24 16:13:31'),
(74, 75, 11, '2018-05-24 16:13:31'),
(75, 76, 10, '2018-05-24 16:19:12'),
(76, 76, 11, '2018-05-24 16:19:12'),
(79, 78, 10, '2018-05-25 16:28:31'),
(80, 78, 11, '2018-05-25 16:28:31'),
(81, 79, 10, '2018-05-25 17:19:57'),
(82, 79, 11, '2018-05-25 17:19:57'),
(85, 81, 10, '2018-05-25 20:47:57'),
(86, 81, 11, '2018-05-25 20:47:57'),
(87, 82, 10, '2018-05-25 20:48:38'),
(88, 82, 11, '2018-05-25 20:48:38'),
(89, 83, 10, '2018-05-25 20:50:03'),
(90, 83, 11, '2018-05-25 20:50:03'),
(91, 84, 10, '2018-05-25 20:50:32'),
(92, 84, 11, '2018-05-25 20:50:32'),
(93, 85, 10, '2018-05-25 20:57:18'),
(94, 85, 11, '2018-05-25 20:57:18'),
(95, 86, 10, '2018-05-25 21:06:49'),
(96, 86, 11, '2018-05-25 21:06:49'),
(97, 87, 10, '2018-05-26 11:17:50'),
(98, 87, 11, '2018-05-26 11:17:51'),
(99, 87, 12, '2018-05-26 11:17:50'),
(100, 87, 13, '2018-05-26 11:17:50'),
(103, 89, 29, '2018-05-28 16:14:37'),
(104, 90, 10, '2018-05-29 09:18:25'),
(105, 90, 11, '2018-05-29 09:18:25');

-- --------------------------------------------------------

--
-- Structure de la table `application`
--

CREATE TABLE IF NOT EXISTS `application` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logo` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `token` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `secret` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `redirect_uri` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_A45BDDC15E237E06` (`name`),
  UNIQUE KEY `UNIQ_A45BDDC15F37A13B` (`token`),
  KEY `IDX_A45BDDC1A76ED395` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='liste des applications' AUTO_INCREMENT=22 ;

--
-- Contenu de la table `application`
--

INSERT INTO `application` (`id`, `user_id`, `name`, `description`, `logo`, `website`, `token`, `secret`, `redirect_uri`, `date`) VALUES
(11, 450, 'Afrimarket', 'Afrimarket est une entreprise specialisée dans le e-commerce', NULL, 'http://afrimarket.ci', 'ZDNmY2IwZDg4ZGM3ZmI5ZThlOWY0Nm', 'MjQ1NTYxZjRiNWQ', 'http://localhost/soutraly/login?m=3', '2018-05-24 14:36:07'),
(19, 460, 'Zafro', 'une application de vente en ligne', '', 'http://localhost/soutraly/login?m=3', 'NmZmNDk0OTQ0MDE5ZWNiNDhhMzFhYm', 'NDdiOTYwOTc3NWN', 'http://localhost/soutraly/login?m=3', '2018-05-26 21:13:17'),
(20, 461, 'Africa million55', 'une application de vente en ligne', '', 'http://soutraly.com', 'MGM3MzQ5YjQ5NjZlNDNlNzJkMzVhMz', 'NDg4Y2Y4ZjVjMWZ', 'http://localhost/soutraly/login?m=3', '2018-05-28 16:07:13'),
(21, 462, 'hookist', 'une application de vente en ligne', '', 'http://localhost/soutraly/login?m=3', 'YTQzYTkwZDc1N2Y1ZjM1MTlhMmNmMj', 'MGQwNjgxZGMwZjA', 'http://localhost/soutraly/login?m=3', '2018-05-29 09:24:59');

-- --------------------------------------------------------

--
-- Structure de la table `app_access_scope`
--

CREATE TABLE IF NOT EXISTS `app_access_scope` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application_id` int(11) NOT NULL,
  `scope_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2BB433013E030ACD` (`application_id`),
  KEY `IDX_2BB43301682B5931` (`scope_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='les scopes requis des applications' AUTO_INCREMENT=36 ;

--
-- Contenu de la table `app_access_scope`
--

INSERT INTO `app_access_scope` (`id`, `application_id`, `scope_id`, `date`) VALUES
(10, 11, 66, '2018-05-24 14:36:07'),
(11, 11, 67, '2018-05-24 00:00:00'),
(12, 11, 72, '2018-05-24 00:00:00'),
(13, 11, 71, '2018-05-24 00:00:00'),
(21, 19, 66, '2018-05-26 21:13:17'),
(22, 19, 67, '2018-05-26 21:13:17'),
(23, 19, 68, '2018-05-26 21:13:17'),
(24, 19, 71, '2018-05-26 21:13:17'),
(25, 19, 72, '2018-05-26 21:13:17'),
(26, 20, 66, '2018-05-28 16:07:13'),
(27, 20, 67, '2018-05-28 16:07:13'),
(28, 20, 68, '2018-05-28 16:07:13'),
(29, 20, 71, '2018-05-28 16:07:13'),
(30, 20, 72, '2018-05-28 16:07:13'),
(31, 21, 66, '2018-05-29 09:24:59'),
(32, 21, 67, '2018-05-29 09:24:59'),
(33, 21, 68, '2018-05-29 09:24:59'),
(34, 21, 71, '2018-05-29 09:24:59'),
(35, 21, 72, '2018-05-29 09:24:59');

-- --------------------------------------------------------

--
-- Structure de la table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_64C19C15E237E06` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(254) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `roles` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649F85E0677` (`username`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=463 ;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`, `is_active`, `roles`) VALUES
(439, 'zakeszako', 'zakeszako@aaz.dev', '$2y$13$QbngiFV.kf78rrtECdJgcOB2Bz2EV0YecvbiQos1GHx3DNDm7ND56', 1, 'a:1:{i:0;s:16:"ROLE_SUPER_ADMIN";}'),
(440, 'username 0', 'user0@aaz.dev', '$2y$13$fwFwUwo1JvHlAjq2HhJx0OrQvlCH145oc3reutyLiLib33ZW/v1K.', 1, 'a:2:{i:0;s:14:"ROLE_MODERATOR";i:1;s:8:"ROLE_API";}'),
(441, 'username 1', 'user1@aaz.dev', '$2y$13$9/TrnVj8VSSLC5yf5TeC8eNV0n4nE2Kp9h2/ibq8XBd6ZhEtnRPyO', 1, 'a:2:{i:0;s:14:"ROLE_MODERATOR";i:1;s:8:"ROLE_API";}'),
(442, 'username 2', 'user2@aaz.dev', '$2y$13$EC/swqTxylteqNfn7LPsoeWqT5Jf5/sfGQvvnOWYPechhQOQ5agzq', 1, 'a:2:{i:0;s:10:"ROLE_ADMIN";i:1;s:8:"ROLE_API";}'),
(443, 'username 3', 'user3@aaz.dev', '$2y$13$YzD5f4k4RZJsBP.WY/0ZPey7flpS/wc5cUSrz1XBx6y4OfI.8M4nS', 1, 'a:2:{i:0;s:14:"ROLE_DEVELOPER";i:1;s:8:"ROLE_API";}'),
(444, 'username 4', 'user4@aaz.dev', '$2y$13$y38UFhNc0dYkgLgONBO4eOglHMeSi3F3uczTrNkpRQ7KRMQvmoiqG', 1, 'a:2:{i:0;s:10:"ROLE_ADMIN";i:1;s:8:"ROLE_API";}'),
(445, 'username 5', 'user5@aaz.dev', '$2y$13$ajIXl16aLRwIvo9aLucW3e3cboCPk.sCOWXQDCwLhuxxFbzKd6lg2', 1, 'a:2:{i:0;s:11:"ROLE_AUTHOR";i:1;s:8:"ROLE_API";}'),
(446, 'username 6', 'user6@aaz.dev', '$2y$13$xuMA26sOHpJWUJ8dlXWgZeyOn9gk72gEG2vLE40mHZlBZprAlojEi', 1, 'a:2:{i:0;s:14:"ROLE_DEVELOPER";i:1;s:8:"ROLE_API";}'),
(447, 'username 7', 'user7@aaz.dev', '$2y$13$AUmuECNpB4hzkog4oV5Wi.NW.RMFpUk7b5kFAJo4BNx2brrom655a', 1, 'a:2:{i:0;s:14:"ROLE_MODERATOR";i:1;s:8:"ROLE_API";}'),
(448, 'username 8', 'user8@aaz.dev', '$2y$13$lcB6kr78yqdxBPNS.ffNYONEjpMlS/sG5g6GjtDA4UcOP0GajiIi2', 1, 'a:2:{i:0;s:11:"ROLE_AUTHOR";i:1;s:8:"ROLE_API";}'),
(449, 'username 9', 'user9@aaz.dev', '$2y$13$M3CccJx7LN.JM0CKXkpfAuMkNHAFJYNlFLAag8v0MfWEp26y1v2nO', 1, 'a:2:{i:0;s:14:"ROLE_DEVELOPER";i:1;s:8:"ROLE_API";}'),
(450, 'Afrimarket', 'info@afrimarket.ci', '$2y$13$HI/ZtC5Y3OJBZyrg5eaJweVTDep19jvrmu/AUbBJQeAFtyApBTWGS', 1, 'a:1:{i:0;s:8:"ROLE_APP";}'),
(460, 'Zafro', NULL, '$2y$13$zUFLnEQcLVE36E3fsUobL.ZYdzk0N6CFocP/7gzne5L7b0ZHq3NF6', 1, 'a:1:{i:0;s:8:"ROLE_APP";}'),
(461, 'Zalando', NULL, '$2y$13$FhijiFlJdIcsv5Ly/DlqjedJyVL2SH..AZYvEUP0.r.DZxPhi4nke', 1, 'a:1:{i:0;s:8:"ROLE_APP";}'),
(462, 'hookist', NULL, '$2y$13$cp3op4pkGNG/8ubLxIPbw.CW1dD/xWalIUQQIWtA0lBd.bQ4vLO1.', 1, 'a:1:{i:0;s:8:"ROLE_APP";}');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `api_user_access_code`
--
ALTER TABLE `api_user_access_code`
  ADD CONSTRAINT `FK_6A493A5F3E030ACD` FOREIGN KEY (`application_id`) REFERENCES `application` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_6A493A5FA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `api_user_access_token`
--
ALTER TABLE `api_user_access_token`
  ADD CONSTRAINT `FK_5A2AAA223E030ACD` FOREIGN KEY (`application_id`) REFERENCES `application` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_5A2AAA22A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `api_user_access_token_scope`
--
ALTER TABLE `api_user_access_token_scope`
  ADD CONSTRAINT `FK_54C07E7941DEE7B9` FOREIGN KEY (`token_id`) REFERENCES `api_user_access_token` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_54C07E79682B5931` FOREIGN KEY (`scope_id`) REFERENCES `app_access_scope` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `application`
--
ALTER TABLE `application`
  ADD CONSTRAINT `FK_A45BDDC1A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `app_access_scope`
--
ALTER TABLE `app_access_scope`
  ADD CONSTRAINT `FK_2BB433013E030ACD` FOREIGN KEY (`application_id`) REFERENCES `application` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_2BB43301682B5931` FOREIGN KEY (`scope_id`) REFERENCES `api_access_scope` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
